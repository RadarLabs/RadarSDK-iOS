//
//  RadarGeofenceGeometry.h
//  RadarSDK
//
//  Copyright © 2019 Radar Labs, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 Represents the geometry of a geofence.
 */
@interface RadarGeofenceGeometry : NSObject

@end
